#!/bin/sh
ROSRV_DIR=/usr/share/roservices
xterm -title "Change VNC Password" -bg black -fg white -hold -e sh $ROSRV_DIR/scripts/change_vnc_pass_script.sh &
