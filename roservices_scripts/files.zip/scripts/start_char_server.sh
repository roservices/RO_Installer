#!/bin/sh
cd /home/roservices/Desktop/rAthena
./char-server
