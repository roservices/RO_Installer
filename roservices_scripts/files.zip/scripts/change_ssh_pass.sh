#!/bin/sh
ROSRV_DIR=/usr/share/roservices
xterm -title "Change SSH Password" -bg black -fg white -hold -e sh $ROSRV_DIR/scripts/change_ssh_pass_script.sh &
