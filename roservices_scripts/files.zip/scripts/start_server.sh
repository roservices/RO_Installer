#!/bin/sh
ROSRV_DIR=/usr/share/roservices
xterm -title "Login Server" -bg black -fg white -hold -e $ROSRV_DIR/scripts/start_login_server.sh &
sleep 1
xterm -title "Char Server" -bg black -fg white -hold -e $ROSRV_DIR/scripts/start_char_server.sh &
sleep 1
xterm -title "Map Server" -bg black -fg white -hold -e $ROSRV_DIR/scripts/start_map_server.sh &
