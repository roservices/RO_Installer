#!/bin/sh
cd /home/roservices/Desktop/rAthena
./map-server
